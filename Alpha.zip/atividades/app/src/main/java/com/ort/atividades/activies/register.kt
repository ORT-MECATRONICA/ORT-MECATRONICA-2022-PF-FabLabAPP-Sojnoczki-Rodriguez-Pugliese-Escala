package com.ort.atividades.activies

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.core.content.ContentProviderCompat.requireContext
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.ort.atividades.R
import com.ort.atividades.databinding.ActivityRegisterBinding
import com.ort.atividades.objects.NewUser

class register : AppCompatActivity() {
    var db = Firebase.firestore
    private lateinit var binding:ActivityRegisterBinding
    private lateinit var actionBar: ActionBar
    private lateinit var progressDialog: ProgressDialog
    private lateinit var firebaseAuth: FirebaseAuth

    private var Email = ""
    private var contra =""
    private var recontra =""
    private var nombre =""
    private var year = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val años = resources.getStringArray(R.array.cursos)
        val adapter= ArrayAdapter(this,R.layout.list_item,años)

        binding.autoCompleteTextView.apply{
            setAdapter(adapter)
        }

        actionBar = supportActionBar!!
        actionBar.title = "Registrate"
        actionBar.setDisplayHomeAsUpEnabled(true)
        actionBar.setDisplayShowHomeEnabled(true)

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Esperate un toque")
        progressDialog.setTitle("Registrando...")
        progressDialog.setCanceledOnTouchOutside(false)

        firebaseAuth = FirebaseAuth.getInstance()

        binding.botonNavigateR.setOnClickListener {
            validateData()
        }
    }

    private fun validateData() {
        Email=binding.userTextR.text.toString().trim()
        contra=binding.passTextR.text.toString().trim()
        recontra=binding.repeatPassTextR.text.toString().trim()
        nombre=binding.nombreTextR.text.toString().trim()
        year = binding.autoCompleteTextView.text.toString()

        if (TextUtils.isEmpty(nombre))
        {
            binding.nombreTextR.error = "Poneme un nombre"
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches()){
            binding.userTextR.error = "Poneme bien el email"
        }
        else if (TextUtils.isEmpty(contra)){
            binding.passTextR.error = "Poneme la contra"
        }
        else if (contra.length <6){
            binding.passTextR.error = "Haceme la contra hasta 6 caracteres"
        }
        else if (recontra != contra){
            binding.repeatPassTextR.error = "Haceme las contras iguales"
        }
        else if (binding.autoCompleteTextView.text.isEmpty()){
            binding.autoCompleteTextView.error = "Seleccione una opcion"
        }
        else{
            firebaseSignUp()
        }
    }

    private fun firebaseSignUp() {
        progressDialog.show()

        firebaseAuth.createUserWithEmailAndPassword(Email, contra)
            .addOnSuccessListener {
                var ref = db.collection("Users").document()
                val idRandom = ref.id

                progressDialog.dismiss()
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email

                val newUser = NewUser(email = Email, userName = nombre, userYear = year)

                db.collection("Users").document(idRandom)
                    .set(newUser).addOnSuccessListener {
                        Toast.makeText(this, "Card subida", Toast.LENGTH_SHORT).show()

                        startActivity(Intent(this, MainActivity2::class.java))
                        finish()
                    }
                    .addOnFailureListener { e ->
                        progressDialog.dismiss()
                        Toast.makeText(
                            this,
                            "Fallo el registro por ${e.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
            }
    }

        override fun onSupportNavigateUp(): Boolean {
            onBackPressed()
            return super.onSupportNavigateUp()
        }
}