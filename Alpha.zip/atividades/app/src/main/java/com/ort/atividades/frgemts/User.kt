package com.ort.atividades.frgemts

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.ort.atividades.R
import com.ort.atividades.activies.LoginActivity
import com.ort.atividades.activies.MainActivity2
import com.ort.atividades.viewmodels.UserViewModel

class user : Fragment() {

    companion object {
        fun newInstance() = user()
    }

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var viewModel: UserViewModel
    private lateinit var boton : Button
    lateinit var v : View
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       v = inflater.inflate(R.layout.user_fragment, container, false)

       boton = v.findViewById(R.id.button)
        firebaseAuth = FirebaseAuth.getInstance()

        return v
    }

    override fun onStart() {
        super.onStart()

        boton.setOnClickListener {
            firebaseAuth.signOut()
            startActivity(Intent(requireContext(),LoginActivity::class.java ))
        }
    }

}