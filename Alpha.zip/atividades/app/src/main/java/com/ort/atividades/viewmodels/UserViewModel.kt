package com.ort.atividades.viewmodels

import androidx.lifecycle.ViewModel

class UserViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}