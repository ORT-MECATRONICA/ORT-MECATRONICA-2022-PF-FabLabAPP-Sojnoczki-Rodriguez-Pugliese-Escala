package com.ort.atividades.viewmodels

import androidx.lifecycle.ViewModel

class UploadViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}