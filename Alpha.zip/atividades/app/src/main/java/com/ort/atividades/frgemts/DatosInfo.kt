package com.ort.atividades.frgemts

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.findNavController
import com.bumptech.glide.Glide
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.ort.atividades.R
import com.ort.atividades.viewmodels.DatosInfoViewModel

class DatosInfo : Fragment() {

    companion object {
        fun newInstance() = DatosInfo()
    }

    val db = Firebase.firestore
    lateinit var v : View
    lateinit var txtNombre :TextView
    lateinit var txtFecha : TextView
    lateinit var txtDescription : TextView
    lateinit var ImgArchivo :ImageView
    lateinit var btnBorrar : Button
    lateinit var btnRegreso : Button

    private lateinit var viewModel: DatosInfoViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.fragment_datos_info, container, false)

        txtNombre = v.findViewById(R.id.nombreInf)
        txtFecha = v.findViewById(R.id.fechaInfo)
        txtDescription = v.findViewById(R.id.descripcion)
        btnBorrar = v.findViewById(R.id.btnBorrar)
        btnRegreso =v.findViewById(R.id.botonRegreso)
        ImgArchivo = v.findViewById(R.id.imageView)

        return v
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(DatosInfoViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onStart() {
        super.onStart()
        var nombre = DatosInfoArgs.fromBundle(requireArguments()).name
        var fecha = DatosInfoArgs.fromBundle(requireArguments()).date
        var imagen = DatosInfoArgs.fromBundle(requireArguments()).img
        var id = DatosInfoArgs.fromBundle(requireArguments()).id
        var description = DatosInfoArgs.fromBundle(requireArguments()).description

        txtNombre.text = nombre
        txtFecha.text = fecha
        txtDescription.text = description

        Glide
            .with(this)
            .load(imagen)
            .centerInside()
            .into(ImgArchivo)

        btnRegreso.setOnClickListener{
            val action = DatosInfoDirections.actionDatosInfoToFiles()
            v.findNavController().navigate(action)
        }

        btnBorrar.setOnClickListener{
            db.collection("card").document(id)
                .delete()
                .addOnSuccessListener {
                    Toast.makeText(requireContext(),"Card Borrada", Toast.LENGTH_SHORT).show()
                }
            val action = DatosInfoDirections.actionDatosInfoToFiles()
            v.findNavController().navigate(action)
        }
    }
}