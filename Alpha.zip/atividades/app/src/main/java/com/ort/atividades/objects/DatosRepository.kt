package com.ort.atividades.objects

class DatosRepository {
    var DatosList:MutableList<Datos> = mutableListOf()
    init {
        DatosList.add(Datos("Martillo", "05/07/22", "https://st.depositphotos.com/1031174/2234/i/600/depositphotos_22348465-stock-photo-hammer.jpg", "a","",""))
        DatosList.add(Datos("Soldador", "05/07/22", "a", "a","",""))
        DatosList.add(Datos("Gasometro", "05/07/22", "a", "a","",""))
        DatosList.add(Datos("Destornillador", "05/07/22", "a", "a","",""))
        DatosList.add(Datos("Parlante", "05/07/22", "a", "a","",""))
        DatosList.add(Datos("Botella", "05/07/22", "a", "a","",""))
        DatosList.add(Datos("Llave", "05/07/22", "a", "a","",""))
        DatosList.add(Datos("Lapicero", "05/07/22", "a", "a","",""))
    }
    fun clearList(){
        DatosList.clear()
    }
}