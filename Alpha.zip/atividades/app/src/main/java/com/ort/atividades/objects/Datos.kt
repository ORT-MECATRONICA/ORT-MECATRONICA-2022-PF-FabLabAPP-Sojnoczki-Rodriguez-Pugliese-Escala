package com.ort.atividades.objects

class Datos(var nombre: String, var fecha: String, var ImgArchivo: String, var ImgEstado: String, var id:String, var description:String)