package com.ort.atividades.viewmodels

import androidx.lifecycle.ViewModel

class FilesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}