package com.ort.atividades.viewmodels

import androidx.lifecycle.ViewModel

class DatosInfoViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}