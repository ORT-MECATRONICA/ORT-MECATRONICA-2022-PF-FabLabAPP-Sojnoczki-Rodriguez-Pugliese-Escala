package com.ort.atividades.frgemts

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.findNavController
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.ort.atividades.viewmodels.HomeViewModel
import com.ort.atividades.R
import java.security.SecureRandom

class Home : Fragment() {

    companion object {
        fun newInstance() = Home()
    }

    var db = Firebase.firestore
    private lateinit var viewModel: HomeViewModel
    private lateinit var boton: Button
    private lateinit var cambiar: Button
    private lateinit var texto: TextView
    lateinit var v: View

    val CHAR_LOWER = "abcdefghijklmnopqrstuvwxyz"
    val CHAR_UPPER = CHAR_LOWER.toUpperCase()
    val NUMBER = "0123456789"

    val DATA_FOR_RANDOM_ID = CHAR_LOWER + CHAR_UPPER + NUMBER

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.home_fragment, container, false)

        boton = v.findViewById(R.id.toUpload)
        texto = v.findViewById(R.id.textView_home)

        return v
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(HomeViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onStart() {
        super.onStart()
        boton.setOnClickListener {
            val action = HomeDirections.actionHome3ToUpload()
            v.findNavController().navigate(action)
        }

    }
}