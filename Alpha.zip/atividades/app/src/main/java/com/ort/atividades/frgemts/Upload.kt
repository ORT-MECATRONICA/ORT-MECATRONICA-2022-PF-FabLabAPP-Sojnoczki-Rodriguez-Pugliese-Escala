package com.ort.atividades.frgemts

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.navigation.findNavController
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.internal.StorageReferenceUri
import com.ort.atividades.R
import com.ort.atividades.viewmodels.UploadViewModel
import java.net.URI
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class Upload : Fragment() {

    companion object {
        fun newInstance() = Upload()
    }

    var db = Firebase.firestore
    private lateinit var firebaseAuth:FirebaseAuth
    lateinit var v:View

    lateinit var nombrePublish : EditText
    lateinit var fechaPublish : EditText
    lateinit var descripicionPublish : EditText
    lateinit var ImgArchivoPublish : ImageButton
    lateinit var archivoPublish : ImageButton
    lateinit var btnPublish : Button
    lateinit var btnVolver : Button

    lateinit var imagenPublish : ImageView
    lateinit var ImageUri :Uri
    lateinit var archivoURI: Uri


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.fragment_upload, container, false)

        nombrePublish = v.findViewById(R.id.publishNombre)
        fechaPublish = v.findViewById(R.id.publishFecha)
        descripicionPublish = v.findViewById(R.id.publishDescription)
        ImgArchivoPublish = v.findViewById(R.id.publishImgArchivo)
        archivoPublish = v.findViewById(R.id.publishArchivo)
        btnPublish = v.findViewById(R.id.botonPublish)
        btnVolver = v.findViewById(R.id.botonToHome)
        imagenPublish = v.findViewById(R.id.preImagen)
        firebaseAuth = FirebaseAuth.getInstance()
        return v
    }

    override fun onStart() {
        super.onStart()

       //var ref = db.collection("card").document()
        //db.collection("card").document("red.id").set(cosa)

        btnPublish.setOnClickListener{
            val progressDialog = ProgressDialog(requireContext())
            progressDialog.setMessage("Publicando archivo...")
            progressDialog.setCancelable(false)
            progressDialog.show()

            var ref = db.collection("card").document()
            val IDRandom = ref.id

            val imageName = IDRandom + "_image"
            val storageReferenceImage = FirebaseStorage.getInstance().getReference("images/$imageName")

            val fileName = IDRandom + "_file"
            val storageReferenceFile = FirebaseStorage.getInstance().getReference("files/$fileName")

            storageReferenceImage.putFile(ImageUri).
            addOnSuccessListener {

                imagenPublish.setImageURI(null)

                val storageRef1 = FirebaseStorage.getInstance().getReference("images/$imageName")

                storageRef1.downloadUrl.addOnCompleteListener{ task ->
                        val ImageUrl = task.result

                    storageReferenceFile.putFile(archivoURI).
                    addOnSuccessListener {

                        val storageRef2 = FirebaseStorage.getInstance().getReference("files/$fileName")

                        storageRef2.downloadUrl.addOnCompleteListener{ task ->
                            val FilesUrl = task.result
                            var firebaseUser = firebaseAuth.currentUser

                            val objetoSubido = hashMapOf(
                                "title" to nombrePublish.text.toString().trim(),
                                "date" to fechaPublish.text.toString().trim(),
                                "userY" to "lectura info firestore",
                                "description" to descripicionPublish.text.toString().trim(),
                                "state" to "incomplete",
                                "new" to "true",
                                "archive" to "false",
                                "image" to ImageUrl,
                                "file" to FilesUrl,
                                "userName" to "Lectura nombre firestore", //para poner display en card
                                "userEmail" to "${firebaseUser?.email}", //para leer en app
                                "serialNum" to "lectura numeros cards",
                                "data-id" to "${IDRandom}"
                            )

                            db.collection("card").document(IDRandom)
                                .set(objetoSubido).addOnSuccessListener {
                                    Toast.makeText(requireContext(),"Card subida", Toast.LENGTH_SHORT).show()
                                }
                            val action = UploadDirections.actionUploadToHome3()
                            v.findNavController().navigate(action)
                        }
                        if(progressDialog.isShowing) progressDialog.dismiss()
                    }.addOnFailureListener{

                        if (progressDialog.isShowing) progressDialog.dismiss()
                        Toast.makeText(requireContext(),"Ocurrio un error al publicar el archivo", Toast.LENGTH_SHORT).show()
                    }
                }
                if(progressDialog.isShowing) progressDialog.dismiss()
            }.addOnFailureListener{

                if (progressDialog.isShowing) progressDialog.dismiss()
                Toast.makeText(requireContext(),"Ocurrio un error al publicar la imagen", Toast.LENGTH_SHORT).show()
            }

        }

        btnVolver.setOnClickListener{
            val action = UploadDirections.actionUploadToHome3()
            v.findNavController().navigate(action)
        }

        ImgArchivoPublish.setOnClickListener{
            btnSelectImagen()
        }
        archivoPublish.setOnClickListener{
            btnSelectArchivo()
        }
    }
    private fun btnSelectImagen(){

        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT

        startActivityForResult(intent, 100)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 100 && resultCode == Activity.RESULT_OK){

            ImageUri = data?.data!!
            imagenPublish.setImageURI(ImageUri)

        }
        if (requestCode == 150 && resultCode == Activity.RESULT_OK){

            archivoURI = data?.data!!
        }
    }
    private fun btnSelectArchivo() {

        val intent = Intent()
        intent.type = "*/*"
        intent.action = Intent.ACTION_GET_CONTENT

        startActivityForResult(intent, 150)
    }

    fun getRandomString() : String{
        val charset = "ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz0123456789"
        return (1..10)
            .map{ charset.random()}
            .joinToString("")
    }

}