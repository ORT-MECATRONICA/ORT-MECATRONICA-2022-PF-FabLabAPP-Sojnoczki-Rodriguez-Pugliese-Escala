package com.ort.atividades.objects

class NewUser (var admin:String = "student",
               var email:String,
               var student:String = "true",
               var userName:String,
               var userYear:String,
               var cards:MutableList<String> = mutableListOf())
{
    constructor():this("","","","","", mutableListOf())
}