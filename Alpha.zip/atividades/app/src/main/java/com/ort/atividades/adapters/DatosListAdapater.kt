package com.ort.atividades.adapters

import android.content.Context
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.ort.atividades.objects.Datos
import com.ort.atividades.R
import com.bumptech.glide.Glide
import com.google.firebase.storage.FirebaseStorage
import java.io.File


class DatosListAdapater(
    private var datosList : MutableList<Datos>,
    val context : Context,
    val onItemClick : (Int) -> Unit
) : RecyclerView.Adapter<DatosListAdapater.DatosHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DatosHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_obj_desc,parent,false)
        return(DatosHolder(view))
    }

    override fun getItemCount(): Int {

        return datosList.size
    }

    override fun onBindViewHolder(holder: DatosHolder, position: Int) {

        holder.setName(datosList[position].nombre)
        holder.setDate(datosList[position].fecha)

        Glide
            .with(context)
            .load(datosList[position].ImgArchivo)
            .centerInside()
            .into(holder.getImageView(datosList[position].ImgArchivo));

        if(datosList[position].ImgEstado == "complete"){
            val url = "https://firebasestorage.googleapis.com/v0/b/fablab-ort.appspot.com/o/estados%2FestadoV.png?alt=media&token=bea8818b-386c-4d89-8fc2-3a343889ffc8"
            Glide
                .with(context)
                .load(url)
                .centerInside()
                .into(holder.getImageViewEstado(url))
        }else{
            val url = "https://firebasestorage.googleapis.com/v0/b/fablab-ort.appspot.com/o/estados%2FestadoR.png?alt=media&token=358425cc-4d82-4219-8963-34eaf613732d"
            Glide
                .with(context)
                .load(url)
                .centerInside()
                .into(holder.getImageViewEstado(url))
        }


        holder.getCardLayout().setOnClickListener() {
            onItemClick(position)
        }

        holder.getCardLayout().setOnClickListener() {
            onItemClick(position)
        }
    }
    class DatosHolder (v: View) : RecyclerView.ViewHolder(v){

        private var view: View

        init {
            this.view = v
        }
        fun setName(name: String){
            val txt:TextView =view.findViewById(R.id.txt_name_item)
            txt.text = name
        }

        fun setDate(date: String){
            val txt:TextView =view.findViewById(R.id.txt_date_item)
            txt.text = date
        }

        fun getCardLayout (): CardView{
            return view.findViewById(R.id.card_package_item)
        }
        fun getImageView (dato : String) : ImageView{
            return view.findViewById(R.id.img_item)
        }
        fun getImageViewEstado (dato : String) : ImageView{
            return view.findViewById(R.id.img_estado)
        }
    }
}