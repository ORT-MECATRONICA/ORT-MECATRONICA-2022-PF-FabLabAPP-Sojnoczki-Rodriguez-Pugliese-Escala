package com.ort.atividades.frgemts

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.ort.atividades.viewmodels.FilesViewModel
import com.ort.atividades.R
import com.ort.atividades.adapters.DatosListAdapater
import com.ort.atividades.objects.Datos
import com.ort.atividades.objects.DatosRepository
import java.text.FieldPosition

class files : Fragment() {

    companion object {
        fun newInstance() = files()
    }

    lateinit var v: View
    lateinit var recDatos: RecyclerView
    private lateinit var linearLayoutManager: LinearLayoutManager
    private var repository = DatosRepository()

    private lateinit var datosListAdapter:DatosListAdapater
    val db = Firebase.firestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.files_fragment, container, false)
        recDatos = v.findViewById(R.id.rec_datos)
        return v
    }

    override fun onStart() {
        super.onStart()

        repository.clearList()
        recDatos.setHasFixedSize(true)
        linearLayoutManager = LinearLayoutManager(context)
        recDatos.layoutManager = linearLayoutManager

        datosListAdapter = DatosListAdapater(repository.DatosList, requireContext()){pos ->
            onItemClick(pos)
        }
        recDatos.adapter = datosListAdapter
        var docRef = db.collection("card")

        docRef.get()
            .addOnSuccessListener { dataSnapshot ->
                if(dataSnapshot != null)
                {
                    for (document in dataSnapshot)
                    {
                        val nombres = Datos(
                            nombre = document.get("title") as String,
                            fecha = document.get("date") as String,
                            ImgArchivo = document.get("image") as String,
                            ImgEstado = document.get("state") as String,
                            id = document.get("data-id") as String,
                            description = document.get("description") as String
                        )
                        android.util.Log.d("Test", "DocumentSnapshot data: ${nombres.toString()}")
                        repository.DatosList.add(nombres)
                    }
                    datosListAdapter = DatosListAdapater(repository.DatosList, requireContext()){pos -> onItemClick(pos)}
                    recDatos.adapter = datosListAdapter
                }
                else
                {
                    android.util.Log.d("Test", "No such document")
                }
            }
            .addOnFailureListener{  exception ->
                android.util.Log.d("Test","get failed with", exception)
            }
    }

    fun onItemClick(position: Int){
        val action = filesDirections.actionFiles2ToDatosInfo(repository.DatosList[position].nombre,
                                                            repository.DatosList[position].fecha,
                                                            repository.DatosList[position].ImgArchivo,
                                                            repository.DatosList[position].id,
                                                            repository.DatosList[position].description)
        v.findNavController().navigate(action)
    }
}