package com.ort.atividades.activies

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import com.google.firebase.auth.FirebaseAuth
import com.ort.atividades.R
import com.ort.atividades.databinding.ActivityMainBinding


class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var actionBar: ActionBar
    private lateinit var progressDialog:ProgressDialog
    private lateinit var firebaseAuth:FirebaseAuth
    private lateinit var contraBox: EditText
    private var email = ""
    private var contra = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        contraBox = findViewById(R.id.passText)
        actionBar = supportActionBar!!
        actionBar.title = "Login"

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Esperate un toque")
        progressDialog.setTitle("Ingresando")
        progressDialog.setCanceledOnTouchOutside(false)

        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()

        binding.registro.setOnClickListener{
            startActivity(Intent(this, register::class.java))
        }
        binding.botonNavigate.setOnClickListener {
            validateData()
        }
    }

    private fun validateData() {
        email = binding.userText.text.toString().trim()
        contra = binding.passText.text.toString().trim()

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            binding.userText.error = "Che flaco te confundiste con el mail"
        }
        else if (TextUtils.isEmpty(contra)) {
            binding.passText.error = "Ingresame la contra"
        }
        else{
            firebaseLogin()
        }
    }

    private fun firebaseLogin() {
        progressDialog.show()
        firebaseAuth.signInWithEmailAndPassword(email, contra)
            .addOnSuccessListener {
                progressDialog.dismiss()

                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(this, "Te loggeaste como $email", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity2::class.java))
                finish()
            }
            .addOnFailureListener { e->
                progressDialog.dismiss()
                Toast.makeText(this, "Te loggeaste mal por ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun checkUser(){
        var firebaseUser = firebaseAuth.currentUser
        if (firebaseUser != null){

            //Toast.makeText(this, "${firebaseUser.email}", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity2::class.java))
            finish()
        }
    }
}